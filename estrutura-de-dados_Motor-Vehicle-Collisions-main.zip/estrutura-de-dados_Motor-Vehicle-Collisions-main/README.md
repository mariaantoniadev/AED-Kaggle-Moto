# Estrutura de Dados e Algoritmos | Motor Vehicle Collisions | 06/11
Aula do dia 06/11 de Estrutura de Dados com Python, usando o dataset do Kaggle "Motor Vehicle Collisions"

+ https://www.kaggle.com/datasets/utkarshx27/motor-vehicle-collisions
+ https://matplotlib.org/stable/gallery/statistics/index.html

****

**Exercícios:** 

1. Dados Gerais
  - Nº Total de Acidentes
  - Nº de Acidentes com Mortes
  - Nº de Acidentes sem Mortes
2. Acidentes por Bairro
3. Gráfico Acidentes por Ano
4. Gráfico de Acidentes com Mortes 

****
